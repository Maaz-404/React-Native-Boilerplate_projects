# React Native Starter Kit 🚀

Bootstrap your app development by using this awesome react native starter kit, integrated with Firebase Auth and Facebook Login. Clone this boilerplate app to get you up and running quickly.

## Fully working features

* Login with Facebook
* User Management with Firebase Auth
* Firebase Firestore Integration
* Email/Password Registration
* Persistent Login Credentials (a.k.a Remember password)
* Logout Functionality
* Beautiful UI and transitions

## App Designs

